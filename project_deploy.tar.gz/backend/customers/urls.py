﻿from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CustomerViewSet

router = DefaultRouter()
router.include_format_suffixes = False
router.register(r'customer', CustomerViewSet)

urlpatterns = [
    path('', include(router.urls)),
]

