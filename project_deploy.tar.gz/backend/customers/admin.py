from django.contrib import admin
from .models import Customer

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'email', 'restaurant', 'loyalty_points', 'total_spent', 'order_count')
    list_filter = ('restaurant',)
    search_fields = ('name', 'phone', 'email')
