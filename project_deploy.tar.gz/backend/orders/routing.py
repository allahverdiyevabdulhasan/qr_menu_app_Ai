from django.urls import re_path
from .consumers import OrderConsumer

websocket_urlpatterns = [
    re_path(r'ws/orders/(?P<restaurant_slug>\w+)/$', OrderConsumer.as_asgi()),
]
